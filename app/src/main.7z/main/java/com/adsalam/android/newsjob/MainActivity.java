package com.adsalam.android.newsjob;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView l;
    Button btn;
    String countryList[] = {
            "Prothom Alo",
            "Kaler Kontho",
            "Jugantor",
            "Ittegaq",
            "Janakontho",
            "Bhorer Kagoj"
    };
    String flags[] = {
            "https://www.prothomalo.com/",
            "https://www.kalerkantho.com/",
            "https://jugantor.com/",
            "https://www.ittefaq.com.bd/",
            "https://www.dailyjanakantha.com/",
            "https://www.bhorerkagoj.com/"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l = (ListView) findViewById(R.id.list);
        Customadapter customAdapter = new Customadapter(getApplicationContext(), countryList, flags);
        l.setAdapter(customAdapter);
    }
}
