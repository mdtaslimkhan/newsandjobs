package com.adsalam.android.newsjob;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class Customadapter  extends BaseAdapter {
    Context context;
    String countryList[];
    String flags[];
    LayoutInflater inflter;

    public Customadapter(Context applicationContext, String[] countryList, String[] flags) {
        this.context = context;
        this.countryList = countryList;
        this.flags = flags;
        inflter = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return countryList.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.list_layout, null);
        TextView country = view.findViewById(R.id.textview);
        country.setText(countryList[i]);
       // icon.setImageResource(flags[i]);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse(flags[i]))
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);;
                view.getContext().startActivity(intent);
                System.out.println("hello bangladesh"+countryList[i]);
            }
        });
        return view;
    }
}
